import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// --- Components ---
import Footer from "./Components/Homecomponents/Footer";
import ScrollToTop from "./ScrollToTop";
import ChatBox from "./Components/Homecomponents/ChatBox";
// --- Pages ---
import PrivacyPolicy from "./pages/PrivacyPolicy";

import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Apply from "./pages/Apply";
import Login from "./pages/Login";
import Referral from "./pages/Referral";
import Signup from "./pages/Signup";
import WebsiteGuard from "./pages/WebsiteGuard";
import TermsAndConditions from "./pages/TermsAndConditions";
const App = () => {
  return (
    <Router>
      <WebsiteGuard></WebsiteGuard>
      {/* Resets scroll position to top on every route change */}
      <ScrollToTop />
      {/* Global Navbar */}
      <div className="min-h-screen">
        <Routes>
          {/* Main Page with Employer Info & Apply Button */}
          <Route path="/" element={<Home />} />
          <Route path="/referral" element={<Referral />} />
          <Route path="/signup" element={<Signup />} />
          {/* About Page: Mission & Culture */}
          <Route path="/about" element={<About />} />
          {/* Contact Page */}
          <Route path="/contact" element={<Contact />} />
          {/* Specialized Cleaner Application Form */}
          <Route path="/apply" element={<Apply />} />
          {/* Worker Login: Separate from Apply Now */}
          <Route path="/login" element={<Login />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/TermsAndConditions" element={<TermsAndConditions />} />
        </Routes>
      </div>
      <ChatBox></ChatBox>
    </Router>
  );
};

export default App;
